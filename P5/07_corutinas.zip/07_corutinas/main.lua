-- Escribe codigo
require "library"
sequences = require "sequence"
window_layer, debug_layer = prepareWindow()

--mySequence = sequences.Sequence:new()

worldSizeX = 1024
worldSizeY = 768

mousePositionX = nil
mousePositionY = nil

-- Define tus variables globales

-- Fin de tus variables globales

-- Define tus funciones

-- Fin de tus funciones

function onDraw()
    -- Escribe tu c�digo para pintar pixel a pixel
    
    -- Fin de tu c�digo
end

function onUpdate(seconds)
    -- Escribe tu c�digo para ejecutar cada frame
    -- Fin del c�digo
end

function onClickLeft(down)
    -- Escribe tu c�digo para el click del rat�n izquierdo (down ser� true si se ha pulsado, false si se ha soltado)
    if down then

    end
    -- Fin del c�digo
end

function onClickRight(down)
    -- Escribe tu c�digo para el click del rat�n derecho (down ser� true si se ha pulsado, false si se ha soltado)
    if down then
    
    end
    -- Fin del c�digo
end

function onMouseMove(posX, posY)
    mousePositionX = posX
    mousePositionY = posY
    -- Escribe tu c�digo cuando el rat�n se mueve
    
    -- Fin del c�digo
end

function onKeyPress(key, down)
    -- Escribe tu c�digo para tecla pulsada (down ser� true si la tecla se ha pulsado, false si se ha soltado)
    
    -- Fin del c�digo
end

callbackConfiguration(onClickLeft, onClickRight, onMouseMove, onKeyPress, onDraw, debug_layer)
mainLoop()

